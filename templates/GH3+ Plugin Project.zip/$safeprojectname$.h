#pragma once


void ApplyHack();


